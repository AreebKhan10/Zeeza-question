import React from 'react'
import  logo from '../assets/Logo.png'

export default function Navbar() {
  return (
    <>
    <div className='flex flex-row bg-[#47529B] logoImage' >
      <img src={logo} className='w-100'></img>
    </div>
    <div  className='flex flex-row justify-between bg-[#EFEEF5] acdemicReport'>
      <h3 className='text-[#1C3E57] font-medium text-xl'>Acadmic Report</h3> 
      <div className="bg-[#EFEEF5] p-2 percentageRatio">
          <p className="text-[#47529B] text-md">8% Complete</p>

          {/* <div class="overflow-hidden h-2 mb-2 text-xs flex rounded bg-white m-1">
            <div class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-[#47529B] w-1/4"></div>
          </div> */}
        </div>
    </div>
    </>
  )
}
